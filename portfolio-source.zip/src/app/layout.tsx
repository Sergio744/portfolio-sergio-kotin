import type { Metadata, Viewport } from "next";
import { Fraunces, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/components/portfolio/LanguageProvider";

const fraunces = Fraunces({
  subsets: ["latin"],
  style: ["normal", "italic"],
  variable: "--font-fraunces",
  axes: ["opsz"],
  display: "swap",
});

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
  display: "swap",
});

const jbmono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-jbmono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Sergio Kotin — Ingénieur logiciel & Consultant IA",
  description:
    "Portfolio de Sergio Kotin, ingénieur logiciel et consultant IA basé au Bénin. SaaS, apps web & desktop, sites web, portfolios et jeux web — développement natif IA. Créateur de Grada, EcoCompta, KlassIn et du jeu open-source Neon Rift.",
  keywords: [
    "Sergio Kotin",
    "ingénieur logiciel",
    "consultant IA",
    "Bénin",
    "développeur",
    "React",
    "TypeScript",
    "Grada",
    "EcoCompta",
    "KlassIn",
    "Neon Rift",
    "jeu open-source",
    "portfolio",
  ],
  authors: [{ name: "Sergio Kotin" }],
  openGraph: {
    title: "Sergio Kotin — Ingénieur logiciel & Consultant IA",
    description:
      "SaaS, apps web & desktop, sites web, portfolios et jeux web — développement natif IA. Créateur de Grada, EcoCompta, KlassIn et du jeu open-source Neon Rift. Basé à Abomey-Calavi, Bénin.",
    type: "website",
    locale: "fr_FR",
  },
};

export const viewport: Viewport = {
  themeColor: "#09080d",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fr"
      suppressHydrationWarning
      className={`${fraunces.variable} ${grotesk.variable} ${jbmono.variable}`}
    >
      <body className="antialiased">
        <LanguageProvider>{children}</LanguageProvider>
      </body>
    </html>
  );
}
